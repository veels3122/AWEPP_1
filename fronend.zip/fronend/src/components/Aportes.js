import React from 'react';

const Aportes = () => {
  return (
    <div>
      <h2>Página de Aportes</h2>
      <p>Aquí puedes ver y administrar todas tus Aportes.</p>
    </div>
  );
};

export default Aportes;
