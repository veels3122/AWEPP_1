import React from 'react';
import InicioForm from "../components/Inicio.form";

const Iniciopage = () => {
    return (
        <>
            <InicioForm />
        </>
    );
}

export default Iniciopage;
